# Hanabira Resource Pack

This is the resource pack for Hanabira.
`play.hanabira-rp.net`

We won't try to hide the pack because you can get it yourself too.
But note that everything in here belongs to Hanabira. Please do not steal it.
Thank you!
